import requests

def get_fangraphs_stats(player_id):
    url = f"https://www.fangraphs.com/api/player/{player_id}"
    r = requests.get(url).json()
    return {
        "event_rate": r.get("wOBA", 0.1)
    }
